package main

import (
	"context"
	"os"
	"os/signal"
	"time"

	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/informers"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/cache"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/client-go/tools/clientcmd/api"
	"k8s.io/klog/v2"
)

func main() {

	// ctx that responds to ctrl-c
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, os.Kill)
	defer cancel()

	// load kube config
	config, err := clientcmd.NewNonInteractiveDeferredLoadingClientConfig(
		clientcmd.NewDefaultClientConfigLoadingRules(),
		&clientcmd.ConfigOverrides{ClusterInfo: api.Cluster{InsecureSkipTLSVerify: true}},
	).ClientConfig()
	if err != nil {
		klog.Fatal("Unable to load kube config: ", err)
	}
	klog.Infof("Loaded configuration for host %v.\n", config.Host)

	// create kube client
	client, err := kubernetes.NewForConfig(config)
	if err != nil {
		klog.Fatal("Unable to create kube client: ", err)
	}

	// kube informer factory
	informers := informers.NewSharedInformerFactory(client, 10*time.Minute)

	// register a handler on the secrets informer
	informers.Core().V1().Secrets().Informer().AddEventHandler(
		&cache.ResourceEventHandlerFuncs{
			AddFunc: func(obj interface{}) {
				klog.Info("ADD  :", obj.(v1.Object).GetNamespace(), obj.(v1.Object).GetName())
			},
			UpdateFunc: func(oldObj, newObj interface{}) {
				klog.Info("UPDATE:", oldObj.(v1.Object).GetNamespace(), oldObj.(v1.Object).GetName())
			},
			DeleteFunc: func(obj interface{}) {
				klog.Info("DELETE:", obj.(v1.Object).GetNamespace(), obj.(v1.Object).GetName())
			},
		},
	)

	// start informers that have event handlers registered
	informers.Start(ctx.Done())

	// wait for process to be interrupted.
	<-ctx.Done()
}
